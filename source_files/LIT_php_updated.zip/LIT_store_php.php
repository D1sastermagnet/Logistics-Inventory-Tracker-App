<?php
//$storeQuery = strval($_GET['query']);
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: X-Requested-With");
header("Access-Control-Allow-Methods: GET, POST");

$con = mysqli_connect('lit-database-1.cvmosvqcsjmo.us-east-2.rds.amazonaws.com','hundredC','hundredC','lit_cart_demo');
//$queryStm = "SELECT * FROM stores WHERE UPPER(storeName) LIKE '%".$storeQuery."%'";
$queryStm = "SELECT * FROM stores";
$result = mysqli_query($con, $queryStm);

$outputArray = array();
if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        $tempArray = array($row['storeID'],$row['storeName'],$row['Address'],$row['closeStore1'],$row['closeStore2']);
        array_push($outputArray, $tempArray);
    }
}

echo json_encode($outputArray);


mysqli_close($con);

?>